﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Globalization;
using ReserveSeat.Models;

namespace ReserveSeat.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public Booking Booking { get; set; }

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {
            string dateTime = DateTime.Now.ToString("d", new CultureInfo("en-US"));
            ViewData["TimeStamp"] = dateTime;

            Booking = new Booking();
            Booking.BookingDate = DateTime.Now;
            Booking.SeatName = "WS001";
            ViewData["Booking"] = Booking;
        }

        public void ButtonSubmit_OnClick()
        {
            
        }
    }
}