﻿namespace ReserveSeat.Models
{
    public class Booking
    {
        public int Id { get; set; }
        public string? SeatName { get; set; }
        public DateTime BookingDate { get; set; }

    }
}
