USE [SeatBooking]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


DROP TABLE [dbo].[SeatAssignment]
GO
DROP TABLE [dbo].[Seat]
GO
DROP TABLE [dbo].[BlockAssignment]
GO
DROP TABLE [dbo].[Block]
GO
DROP TABLE [dbo].[FloorMap]
GO
DROP TABLE [dbo].[Employee]
GO
DROP TABLE [dbo].[Department]
GO



