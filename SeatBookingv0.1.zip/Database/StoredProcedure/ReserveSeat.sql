USE [SeatBooking]
GO

/****** Object:  StoredProcedure [dbo].[ReserveSeat]    Script Date: 7/8/2023 1:05:21 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[ReserveSeat] @EmployeeId int, @SeatId int, @Date date
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
    -- Insert statements for procedure here
	INSERT INTO [dbo].[SeatAssignment]([SeatId],[EmployeeId],[Date]) VALUES (@SeatId, @EmployeeId, @Date)
END TRY
BEGIN CATCH
	SELECT ERROR_NUMBER() AS ErrorNumber,
	ERROR_MESSAGE() AS ErrorMessage
END CATCH
GO


