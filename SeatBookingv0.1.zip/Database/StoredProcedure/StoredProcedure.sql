-- ================================================
-- Template generated from Template Explorer using:
-- Create Procedure (New Menu).SQL
--
-- Use the Specify Values for Template Parameters 
-- command (Ctrl-Shift-M) to fill in the parameter 
-- values below.
--
-- This block of comments will not be included in
-- the definition of the procedure.
-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================

DROP PROCEDURE [dbo].[ReserveSeat]
GO

CREATE PROCEDURE ReserveSeat @EmployeeId int, @SeatId int, @StartDate date, @EndDate date
AS
BEGIN TRY
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
    -- Insert statements for procedure here
	INSERT INTO [dbo].[SeatAssignment]([SeatId],[EmployeeId],[StartDate],[EndDate]) VALUES (@SeatId, @EmployeeId, @StartDate, @EndDate)
END TRY
BEGIN CATCH
	SELECT ERROR_NUMBER() AS ErrorNumber,
	ERROR_MESSAGE() AS ErrorMessage
END CATCH
GO
