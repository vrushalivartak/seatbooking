USE [SeatBooking]
GO

INSERT INTO [dbo].[Department]([Name]) VALUES ('R&D Banking')
INSERT INTO [dbo].[Department]([Name]) VALUES ('PS Banking')
INSERT INTO [dbo].[Department]([Name]) VALUES ('R&D Retail')
INSERT INTO [dbo].[Department]([Name]) VALUES ('PS Retail')
GO

INSERT INTO [dbo].[Employee]([Name],[DepartmentId]) VALUES ('Vrushali', 1)
INSERT INTO [dbo].[Employee]([Name],[DepartmentId]) VALUES ('Jomy', 1)
INSERT INTO [dbo].[Employee]([Name],[DepartmentId]) VALUES ('Jyoti', 1)
INSERT INTO [dbo].[Employee]([Name],[DepartmentId]) VALUES ('Pratul', 2)
INSERT INTO [dbo].[Employee]([Name],[DepartmentId]) VALUES ('Meenakshy', 2)
INSERT INTO [dbo].[Employee]([Name],[DepartmentId]) VALUES ('Puneet', 3)
INSERT INTO [dbo].[Employee]([Name],[DepartmentId]) VALUES ('Kairan', 3)
INSERT INTO [dbo].[Employee]([Name],[DepartmentId]) VALUES ('Diwakar', 4)
GO

/*
INSERT INTO [dbo].[Block]([Name],[Rows],[SeatsPerRow]) VALUES (1, 'North1', 10, 4)
INSERT INTO [dbo].[Block]([Name],[Rows],[SeatsPerRow]) VALUES (2, 'North2', 10, 7)
INSERT INTO [dbo].[Block]([Name],[Rows],[SeatsPerRow]) VALUES (3, 'North3', 2, 5)
INSERT INTO [dbo].[Block]([Name],[Rows],[SeatsPerRow]) VALUES (4, 'North4', 10, 4)
INSERT INTO [dbo].[Block]([Name],[Rows],[SeatsPerRow]) VALUES (5, 'North5', 5, 5)
GO
*/

INSERT INTO [dbo].[Block]([Name],[RowsInBlock],[SeatsPerRow]) VALUES ('North1', 5, 5)
INSERT INTO [dbo].[Block]([Name],[RowsInBlock],[SeatsPerRow]) VALUES ('North2', 5, 5)
INSERT INTO [dbo].[Block]([Name],[RowsInBlock],[SeatsPerRow]) VALUES ('North3', 5, 5)
INSERT INTO [dbo].[Block]([Name],[RowsInBlock],[SeatsPerRow]) VALUES ('North4', 5, 5)
INSERT INTO [dbo].[Block]([Name],[RowsInBlock],[SeatsPerRow]) VALUES ('North5', 5, 5)
GO

INSERT INTO [dbo].[BlockAssignment]([BlockId],[DepartmentId],[StartDate],[EndDate]) VALUES (1, 2, null, null)
INSERT INTO [dbo].[BlockAssignment]([BlockId],[DepartmentId],[StartDate],[EndDate]) VALUES (2, 1, null, null)
INSERT INTO [dbo].[BlockAssignment]([BlockId],[DepartmentId],[StartDate],[EndDate]) VALUES (4, 3, null, null)
INSERT INTO [dbo].[BlockAssignment]([BlockId],[DepartmentId],[StartDate],[EndDate]) VALUES (5, 4, null, null)
GO

INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS001', 1)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS002', 1)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS003', 1)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS004', 1)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS005', 1)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS006', 2)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS007', 2)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS008', 2)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS009', 2)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS010', 2)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS011', 3)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS012', 3)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS013', 3)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS014', 3)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS015', 3)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS016', 4)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS017', 4)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS018', 4)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS019', 4)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS020', 4)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS021', 5)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS022', 5)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS023', 5)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS024', 5)
INSERT INTO [dbo].[Seat]([Name],[BlockId]) VALUES ('WS025', 5)
GO

INSERT INTO [dbo].[FloorMap]([BlockRows],[BlockColumns]) VALUES (2, 3)
GO

INSERT INTO [dbo].[SeatAssignment]([SeatId],[EmployeeId],[Date]) VALUES (1, 2, '2023-07-07')
GO
