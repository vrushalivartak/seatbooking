USE [SeatBooking]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Department](
	[Id] [int] NOT NULL IDENTITY(1,1),
	[Name] [varchar](50) NOT NULL,
	PRIMARY KEY (ID)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Employee](
	[Id] [int] NOT NULL IDENTITY(1,1),
	[Name] [varchar](50) NOT NULL,
	[DepartmentId] [int] NOT NULL,
	PRIMARY KEY (ID),
	FOREIGN KEY (DepartmentId) REFERENCES Department(Id)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Block](
	[Id] [int] NOT NULL IDENTITY(1,1),
	[Name] [varchar](50) NOT NULL,
	[PositionRow] [int] NULL,
	[PositionColumn] [int] NULL,
	[RowsInBlock] [int] NOT NULL,
	[SeatsPerRow] [int] NOT NULL,
	PRIMARY KEY (ID)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[BlockAssignment](
	[Id] [int] NOT NULL IDENTITY(1,1),
	[BlockId] [int] NOT NULL,
	[DepartmentId] [int] NOT NULL,
	[StartDate] [date] NULL,
	[EndDate] [date] NULL,
	PRIMARY KEY (ID),
	FOREIGN KEY (BlockId) REFERENCES [Block](Id),
	FOREIGN KEY (DepartmentId) REFERENCES Department(Id)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[Seat](
	[Id] [int] NOT NULL IDENTITY(1,1),
	[Name] [varchar](50) NOT NULL,
	[BlockId] [int] NOT NULL,
	PRIMARY KEY (ID),
	FOREIGN KEY (BlockId) REFERENCES [Block](Id),
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[SeatAssignment](
	[Id] [int] NOT NULL IDENTITY(1,1),
	[SeatId] [int] NOT NULL,
	[EmployeeId] [int] NOT NULL,
	[Date] [varchar](10) NULL,
	FOREIGN KEY (SeatId) REFERENCES [Seat](Id),
	FOREIGN KEY (EmployeeId) REFERENCES Employee(Id),
	CONSTRAINT UQ_SeatId_Date UNIQUE(SeatId, [Date]),
	CONSTRAINT UQ_EmployeeId_Date UNIQUE(EmployeeId, [Date])
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[FloorMap](
	[Id] [int] NOT NULL IDENTITY(1,1),
	[BlockRows] [int] NOT NULL,
	[BlockColumns] [int] NOT NULL,
	PRIMARY KEY (ID),
) ON [PRIMARY]
GO

