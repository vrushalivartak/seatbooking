USE [SeatBooking]
GO

/****** Object:  Table [dbo].[Department]    Script Date: 7/7/2023 1:07:36 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Department](
	[Id] [int] NOT NULL,
	[Name] [varchar](50) NOT NULL,
	PRIMARY KEY (ID)
) ON [PRIMARY]
GO


